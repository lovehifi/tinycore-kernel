import os
import sys

peppy_meter_path = os.path.join(os.getcwd(), "screensaver", "peppymeter")
sys.path.append(peppy_meter_path)