#!/bin/sh
/usr/bin/gpio mode 3 out
/usr/bin/gpio write 3 1

